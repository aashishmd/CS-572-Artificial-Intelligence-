{\rtf1\ansi\ansicpg1252\cocoartf1504
{\fonttbl\f0\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;\csgray\c100000;\cssrgb\c0\c0\c0;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 \'97\'97 Run in an IDE\'97 \'97 \
Use IDE like eclipse to run the program or pyrite to run it\
\
\'97 \'97 Compile the Java file \'97\'97 \
\pard\pardeftab720\sl280\partightenfactor0
\cf2 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 Change intodirectories inside "sources" and use\
the command \
                  javac *.java\
\
in this case: javac WebSearch.java\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0
\cf0 \kerning1\expnd0\expndtw0 \outl0\strokewidth0 \
Run: \
Use the command\
			   java filename\
\
in this case:	   java WebSearch \
}